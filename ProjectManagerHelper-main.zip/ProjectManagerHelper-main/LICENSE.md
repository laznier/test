# Proprietary - Free to Use, No Modifications Without Permission

You are free to **use** this software in its original, unmodified form for personal or internal business purposes at no charge. However:

1. **No Modification or Distribution**  
   ... [license text continues] ...
